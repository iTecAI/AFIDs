from avgcolor import *
from time import sleep
from picamera import PiCamera
from twilio.rest import Client
from urllib.request import urlopen
import json
from os import remove
from gpiozero import LED
from threading import Thread
status = LED(2)
status.on()
curr_ip = str(urlopen('http://ip.42.pl/raw').read()).strip("b'")
cam = PiCamera()
#get geolocation
JSON = str(urlopen('http://api.ipstack.com/' + curr_ip + '?access_key=a16287cab90cbabcdf954cd84bafd87b').read()).strip("b'")
JSON = json.loads(JSON)
pos = [JSON['latitude'], JSON['longitude']]

acc = 'AC9c4d1dec9dbcd439e3d4f465ebea7606'
tok = '029ac7c7649e4905de20903b4be73dda'
client = Client(acc, tok)

def msg(msg, to):
    global client
    return client.messages.create(to=to, from_="+13345183243", body=msg)

def BlinkThread():
    global status
    data = open('data.txt', 'w')
    data.write('')
    data.close()
    lmsg = None
    while lmsg != 'end':
        status.on()
        sleep(0.1)
        status.off()
        sleep(0.1)
        data = open('data.txt', 'r')
        lmsg = data.read()
        data.close()
    status.on()

def picapture(): #use picamera to take picture and return img path
    global cam
    
    try:
        os.remove('images/current.jpg')
    except:
        pass
    cam.start_preview()
    sleep(0.5)
    cam.capture('images/current.jpg')
    cam.stop_preview()
    
    return 'images/current.jpg'
file = picapture()
while file != None:
    status.off()
    t = Thread(target=BlinkThread)
    t.start()
    avg = get_avg(file, 'r')
    print(avg)
    if avg >= 90:
        
        msg('Fire detected at latitude:' + str(pos[0]) + ' and longitude: ' + str(pos[1]), '+16039986474')
    data = open('data.txt', 'w')
    data.write('end')
    data.close()
    sleep(5)
    file = picapture()
    

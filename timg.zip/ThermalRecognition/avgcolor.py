import pygame

def get_avg(IF, color):
    pygame.init()
    img = pygame.image.load(IF)
    dims = img.get_size()
    #print(dims)
    pvals = []
    for x in range(dims[0] - 1):
        for y in range(dims[1] - 1):
            if color == 'r':
                pvals.append(img.get_at([x,y]).r)
            elif color == 'g':
                pvals.append(img.get_at([x,y]).g)
            else:
                pvals.append(img.get_at([x,y]).b)
    return sum(pvals) / len(pvals)


                
                             
            
                         
